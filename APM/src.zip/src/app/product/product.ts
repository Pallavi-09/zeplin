export interface IProduct {
    ImageUrl : string;
    Product : string;
    code: string;
    Available: string;
    Price:number;
    Star_Rating:number;
}